//
//  README.swift
//  IterationOne_ToDoList
//
//

//INSTRUCTIONS FOR USE

//This is a template to help with iteration 0 of the ToDo List project. It has all files that you will need for the entire project.

//A few notes:
// => Stacks are already included.
// => Modifiers are not included (including padding modifiers).
//=> The List view is already included.
