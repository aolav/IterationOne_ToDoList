//
//  Persistence.swift
//  IterationOne_ToDoList
//
//

//** This file contains all the code for the ToDoItem class**

import CoreData
