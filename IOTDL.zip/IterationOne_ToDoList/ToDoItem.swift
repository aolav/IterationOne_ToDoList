//
//  ToDoItem.swift
//  IterationOne_ToDoList

//

//** This file contains all the code for the ToDoItem class**

import Foundation

class ToDoItem {
    //Change the class to ToDoItem: Identifiable
    
    //Add the variable id and set it equal to type UUID()
    
    var title = ""
    var isImportant = false
    
    init(title: String, isImportant: Bool = false) {
        self.title = title
        self.isImportant = isImportant
    }
}
